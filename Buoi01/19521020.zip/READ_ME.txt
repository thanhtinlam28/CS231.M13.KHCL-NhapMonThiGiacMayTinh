1. Open folder in windows terminal
2. run "code ." to see images in jupyter notebook.